# 🏋️ Mini App de Treino de Wing chun Diario (PWA)

![Status](https://img.shields.io/badge/status-ready-success)
![License](https://img.shields.io/badge/license-MIT-blue)
![Built_with](https://img.shields.io/badge/built%20with-JavaScript%20%26%20HTML5-yellow)
![Platform](https://img.shields.io/badge/platform-PWA%20(Offline%20Ready)-orange)

Um **Progressive Web App (PWA)** leve e responsivo criado para **registrar treinos diários de Wing Chun**, acompanhar o progresso e funcionar **mesmo offline**. Ideal para treinos de forma, combos e condicionamento — com estética premium preto & dourado.

---

## 🌟 Funcionalidades

- ✅ Registro rápido de treinos do dia (persistente)
- 🧠 Armazenamento local via `localStorage`
- ⚙️ Suporte **offline** com Service Worker
- 📱 Instalável em Android/Desktop (via Chrome/Edge)
- 🖼️ Mockups e README já incluídos para exposição no GitHub

---

## 🔗 Demonstração

Será publicada em:  
https://willechun.github.io/meu-treino-pwa/

---

## 📂 Estrutura do Projeto

```
meu-treino-pwa/
├── index.html
├── manifest.json
├── service-worker.js
├── icons/
│   ├── icon-192.png
│   └── icon-512.png
└── assets/
    ├── preview-app.png
    └── preview-install.png
```

---

## ⚙️ Como publicar no GitHub Pages (rápido)

1. Crie o repositório: `meu-treino-pwa` no GitHub (público).
2. Faça upload de todos os arquivos e pastas (arrastar e soltar funciona).
3. Em **Settings → Pages** selecione: **Branch: main** e **Folder: / (root)**.
4. Salve e aguarde alguns segundos. O site ficará disponível em:
   `https://willechun.github.io/meu-treino-pwa/`

---

## 📦 Uso local

Clone ou descompacte e rode um servidor local (opcional):
```bash
npx serve .
# abra http://localhost:3000
```

---

## 🎨 Tema visual

Tema aplicado: **Preto & Dourado (premium / marcial)** — ideal para Wing Chun e treinamento disciplinado.

---

## 🧩 Próximos passos (sugestões)

- Adicionar histórico de treinos e gráficos (Chart.js)
- Notificações push para lembrar treinos
- Autenticação e sincronização (opcional)
- Exportar/importar treinos (JSON/CSV)

---

## 📸 Previews

![App Preview](assets/preview-app.png)
![Install Preview](assets/preview-install.png)

---

## 📜 Licença
MIT — feito para aprendizado e experimentação.

---
Desenvolvido por **Wille Santos / @willechun** como parte do Programa de Domínio Rápido em JavaScript.
